<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
   <script src="./script.js"></script>
    <div id="te"><p>HYPERLOOP STUDIOS</p></div>
    <div class="navbar">
        <a href="#home">Home</a>
        <a href="#new">New</a>
        <a href="#startup">Startups</a>
        <a href="#founders">Founders</a>
    </div>